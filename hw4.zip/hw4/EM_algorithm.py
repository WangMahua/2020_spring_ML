#! /usr/bin/env python3
# coding=UTF-8
# This Python file uses the following encoding: utf-8

from __future__ import division                                                 
from __future__ import print_function                                                                                                                                                                   
                                                                          
import os                                                                       
import sys                                                                      
import struct                                                                                                                                         
import gzip
import math


image_size = 28

def pixel_convert(x):
    count = 0
    while x > 8 :
        count+=1
        x=x-8
    return count

def load_image_data(image_file):
    image = []
    image_for_discrete = []
    magic_number = image_file.read(4)
    magic_number = int.from_bytes(magic_number, byteorder='big') # byteorder='big':輸入左邊bit為高位，右邊為低位
    images_number = image_file.read(4)
    images_number = int.from_bytes(images_number, byteorder='big') # byteorder='big':輸入左邊bit為高位，右邊為低位
    rows_number = image_file.read(4)
    rows_number = int.from_bytes(rows_number, byteorder='big') # byteorder='big':輸入左邊bit為高位，右邊為低位
    columns_number = image_file.read(4)
    columns_number = int.from_bytes(columns_number, byteorder='big') # byteorder='big':輸入左邊bit為高位，右邊為低位
    for i in range(images_number):
        temp_image = []
        temp_image_for_discrete = []
        for j in range(rows_number*columns_number):
            data = image_file.read(1)
            data = int.from_bytes(data, byteorder='big')
            data_for_discrete = pixel_convert(data)
            temp_image.append(data)
            temp_image_for_discrete.append(data_for_discrete)
        image.append(temp_image)
        image_for_discrete.append(temp_image_for_discrete)
    #print(image)  
    return image ,image_for_discrete

def load_label_data(label_file):
    label = []
    magic_number = label_file.read(4)
    magic_number = int.from_bytes(magic_number, byteorder='big') # byteorder='big':輸入左邊bit為高位，右邊為低位
    items_number = label_file.read(4)
    items_number = int.from_bytes(items_number, byteorder='big') # byteorder='big':輸入左邊bit為高位，右邊為低位
   
    for i in range(items_number):
        data = label_file.read(1)
        data = int.from_bytes(data, byteorder='big')
        label.append(data)
    return label      


def print_test_image(image_list,label_list):
    data=open("output_image.txt",'w+')
    data.write("Imagination of numbers in Bayesian classifier:\n")
    for i in range(len(image_list)):
        data.write(str(label_list[i])+":\n")
        for j in range(28):
            for k in range(28):
                if image_list[i][k+28*j]<8:
                    data.write("0")
                else:
                    data.write("1")                
            data.write("\n")
        data.write("\n")
    data.write("\n")
    return 0 

def main():
    toggle = 0
    toggle=input('enter toggle:')
    
    #train data
    t_i_f = gzip.open("train-images-idx3-ubyte.gz", "rb")
    train_image_list,train_image_list_for_discrete = load_image_data(t_i_f)
    t_l_f = gzip.open("train-labels-idx1-ubyte.gz", "rb")
    train_label_list = load_label_data(t_l_f)
    #test data
    t_i_f = gzip.open("t10k-images-idx3-ubyte.gz", "rb")
    test_image_list,test_image_list_for_discrete = load_image_data(t_i_f)
    t_l_f = gzip.open("t10k-labels-idx1-ubyte.gz", "rb")
    test_label_list = load_label_data(t_l_f)

